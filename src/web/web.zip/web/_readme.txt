1.) run .\createHeaderFile.bat
2.) convert files from stripped on webpage https://www.mischianti.org/online-converter-file-to-cpp-gzip-byte-array-3/
3.) insert hex-array in website.h